package gaurav

trait Quu {
  def Enque();

}